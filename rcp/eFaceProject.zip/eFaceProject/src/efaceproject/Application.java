package efaceproject;

import com.soyatec.eface.ui.RCPApplication;

/**
 * This class controls all aspects of the application's execution
 */
public class Application extends RCPApplication {
}
