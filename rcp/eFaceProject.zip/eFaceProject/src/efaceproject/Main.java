package efaceproject;

import com.soyatec.eface.upf.MessageBox;
import com.soyatec.eface.upf.MessageBoxButton;
import com.soyatec.eface.upf.MessageBoxImage;
import com.soyatec.eface.upf.MessageBoxOptions;
import com.soyatec.eface.upf.MessageBoxResult;
import com.soyatec.eface.upf.Window;
import com.soyatec.eface.upf.actions.RoutedEventArgs;

public class Main extends Window {

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onOpen(Object sender, RoutedEventArgs eventArgs) {
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onSave(Object sender, RoutedEventArgs eventArgs) {
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onQuit(Object sender, RoutedEventArgs eventArgs) {
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onAbout(Object sender, RoutedEventArgs eventArgs) {
		MessageBox.Show("eFace RCP Application 1.0.1", "About",
				MessageBoxButton.OK, MessageBoxImage.Information,
				MessageBoxResult.Cancel, MessageBoxOptions.DefaultDesktopOnly);
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onEditDelete(Object sender, RoutedEventArgs eventArgs) {
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onEditCopy(Object sender, RoutedEventArgs eventArgs) {
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onEditCut(Object sender, RoutedEventArgs eventArgs) {
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onEditPaste(Object sender, RoutedEventArgs eventArgs) {
	}

	/**
	 * @param sender
	 * @param eventArgs
	 */
	public void onWelcome(Object sender, RoutedEventArgs eventArgs) {
		MessageBox.Show("eFace RCP Application 1.0.1", "Welcome",
				MessageBoxButton.OK, MessageBoxImage.Information,
				MessageBoxResult.Cancel, MessageBoxOptions.DefaultDesktopOnly);
	}
}