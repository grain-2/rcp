package com.junitTest;

public class HelloWorld {
	public String SayHelloWorld() {
		return ("Hello World!!!");
	}
}
