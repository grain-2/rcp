package com.junitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class HelloJUnit4Test {
	private HelloJUnit helloJUnit;

	public HelloJUnit4Test() {
		super();
		System.out.println("new test instance...");
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("before all tests...");

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("after all tests... ");

	}

	@Before
	public void setUp() throws Exception {
		helloJUnit = new HelloJUnit();
		System.out.println("before test...");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("after test...");
	}

	@Test
	public void  testAdd() {
		System.out.println("testAdd() test...");
		assertEquals(29, helloJUnit.add(10, 19));
		assertEquals(9, helloJUnit.add(10, -1));
	}

	@Test
	public void testSub() {
		System.out.println("testSub() test...");
		assertEquals(-44, helloJUnit.sub(-25, 19));
		assertEquals(12, helloJUnit.sub(17, 5));
	}

	@Test
	public void testMul() {
		System.out.println("testMul() test...");
		assertEquals(-625, helloJUnit.mul(-25, 25));
		assertEquals(30, helloJUnit.mul(6, 5));
	}

	@Test
	public void testDiv() {
		System.out.println("testDiv() test...");
		assertEquals(7, helloJUnit.div(49, 7));
		assertEquals(25, helloJUnit.div(125, 5));
	}

}
