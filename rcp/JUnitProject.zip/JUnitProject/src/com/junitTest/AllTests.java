package com.junitTest;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for com.junitTest");
		// $JUnit-BEGIN$
		suite.addTestSuite(HelloJUnit3Test.class);
		suite.addTestSuite(HelloWorldTest.class);
		// $JUnit-END$
		return suite;
	}

}
