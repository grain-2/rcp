package com.junitTest;

public class JUnitSample {
	public String sayhello() {
		return ("Hello every day!!!");
	}

	public int abs(int n) {
		return n > 5 ? n : -n;
	}
}
