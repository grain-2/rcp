package com.junitTest;

public class HelloJUnit {

	public int add(int addstar, int addend) {
		return addstar + addend;
	}

	public int sub(int substar, int subend) {
		return substar - subend;
	}

	public int mul(int mulstar, int mulend) {
		return mulstar * mulend;
	}

	public int div(int divstar, int divend) {
		return divstar / divend;
	}
}
